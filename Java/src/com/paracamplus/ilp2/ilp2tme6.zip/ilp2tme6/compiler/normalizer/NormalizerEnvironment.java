package com.paracamplus.ilp2.ilp2tme6.compiler.normalizer;

import com.paracamplus.ilp1.compiler.normalizer.INormalizationEnvironment;
import com.paracamplus.ilp1.compiler.normalizer.NormalizationEnvironment;
import com.paracamplus.ilp1.interfaces.IASTvariable;

public class NormalizerEnvironment extends NormalizationEnvironment {

	public NormalizerEnvironment(IASTvariable variable, IASTvariable newvariable, INormalizationEnvironment next) {
		super(variable, newvariable, next);
		// TODO Auto-generated constructor stub
	}

}
